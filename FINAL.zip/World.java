public class World{
	
	public static void main(String[] args){ 
			Board board = new Board();
			//board.clearArray();
		}
}